# EchoVerse – AI Voice Generator

Convert text to speech with stylish UI and multiple language support.

## Setup

```bash
pip install -r requirements.txt
python main.py
```

## Languages Supported

- English (Emma)
- Hindi (Aarohi)
- Telugu (Ravi)